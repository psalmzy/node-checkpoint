const fs = require('fs');

// Write data to welcome.txt
fs.writeFileSync('welcome.txt', 'Hello Node');

// Read and console.log data from welcome.txt
const data = fs.readFileSync('welcome.txt', 'utf-8');
console.log(data);
